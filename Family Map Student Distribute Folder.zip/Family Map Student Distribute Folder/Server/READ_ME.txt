From a linux computer:
	navigate to this folder in a terminal.
	Enter the command "java -jar FamilyMapServer_vX-X.jar 8080"	
    ----(Substitute X-X with the appropriate version number)----
	In a browser go to localhost:8080
	Try out and learn how the server expects and delivers data.

		//8080 can be replaced with any port number you choose

View on github: https://github.com/BYUCS240TA/FamilyMapServer
